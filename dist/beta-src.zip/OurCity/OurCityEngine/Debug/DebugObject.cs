#region Using Statements
using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using JigLibX.Collision;
using JigLibX.Physics;
using JigLibX.Geometry;
using JigLibX.Math;
using Microsoft.Xna.Framework.Graphics;
#endregion

namespace OurCityEngine.PhysicObjects
{
    /// <summary>
    /// Immovable object without colision skin
    /// 
    /// <remarks>Usefull for showing waypoints for example.</remarks>
    /// </summary>
    public class DebugObject : PhysicObject
    {
        public DebugObject(Game game, Model model, float radius, Matrix orientation, Vector3 position)
            : base(game, model)
        {
            body = new Body();
            body.CollisionSkin = null;
            body.Immovable = true;
            body.MoveTo(position, orientation);
            body.EnableBody();
            this.scale = Vector3.One * radius;
        }

        public override void ApplyEffects(BasicEffect effect)
        {
            effect.DiffuseColor = color;
        }

    }
}
