﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

namespace OurCityEngine.Debug
{
    /// <summary>
    /// Class that holds DebugDrawer instance
    /// </summary>
    public class DebugManager
    {
        private static DebugManager instance;

        public static DebugManager Instance
        {
            get
            {
                if (instance == null)
                    instance = new DebugManager();

                return instance;
            }
        }

        private DebugManager()
        { }

        public DebugDrawer Drawer { get; set; }

        public void Update(GameTime gameTime)
        {
            //Drawer.Update(gameTime);
        }


    }
}
