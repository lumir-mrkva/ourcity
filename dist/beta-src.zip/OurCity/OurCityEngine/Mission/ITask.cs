﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

namespace OurCityEngine.Mission
{
    /// <summary>
    /// Task interface
    /// </summary>
    public interface ITask
    {
        void Initialize();
        void Update(GameTime gameTime);
        bool DoesConsumeTime();
    }
}
