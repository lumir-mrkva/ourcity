﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OurCity.Player
{
    /// <summary>
    /// Holds information abou player's game progress.
    /// </summary>
    class PlayerContext
    {
    }
}
